
// -------1 задача-----------

// let arr1 = [1, 2, 3, 4, 5]
//  for (let i = 0; i < arr1.length; i++) {
//    document.write(arr1[i]);;
//  }

// ------2 задача--------------

// for (let i = 1; i < 101; i++) {
//   document.write(i + "<br>");
// }

// ------3 задача--------------

// for (let i = 11; i < 34; i++) {
//     document.write(i + "<br>");
//     }

// ------4 задача--------------

// let arr2 = [1, 2, 3, 4, 5];
// let result = 0;
// for (let i = 0; i < arr2.length; i++) {
//   result += arr2[i];
// }
// console.log(result);
